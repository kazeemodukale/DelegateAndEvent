﻿using System;

public class Anagram
{
    public static void Main(string[] args)
    {
        Console.WriteLine(AnagramMethod("Lagos", "Kazeem"));
        Console.WriteLine(AnagramMethod("kazeem", "zakeem"));
        Console.ReadLine();
    }

    public static bool AnagramMethod(string s, string t)
    {
        bool res = true;
        if (s.Length != t.Length)
        {
            res = false;
        }
        else
        {
            s.ToUpper();  // is good to first convert to the same case.
            t.ToUpper();
            var sChar = s.ToCharArray();
            var tChar = t.ToCharArray();
            Array.Sort(sChar);
            Array.Sort(tChar);
            for (int i = 0; i < tChar.Length; i++)
            {
                if (sChar[i] != tChar[i])
                {
                    res = false;
                }              
            }                     
        }
        return res;
    }
}